<?php
###
#Define any overrides you want here
##



# Include more user-defined overrides if they exist.
if( file_exists( "/etc/ganglia-webfrontend/conf.php" ) ) {
  include_once "/etc/ganglia-webfrontend/conf.php";
}
?>
